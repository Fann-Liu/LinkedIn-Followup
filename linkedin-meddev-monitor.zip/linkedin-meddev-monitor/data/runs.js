window.MEDDEV_RUNS = [
  {
    "date": "2026-06-04",
    "runAt": "2026-06-04T11:18:22+08:00",
    "type": "manual-scope-test",
    "added": 3,
    "updated": 0,
    "summary": "新口径测试运行，新增 3 个北欧眼科医疗技术公司，并补充 CEO/Founder LinkedIn 链接。"
  }
];
