window.MEDDEV_CONFIG = {
  title: "北欧眼科医疗技术 LinkedIn 账号监测",
  timezone: "Asia/Shanghai",
  timezoneLabel: "UTC+8",
  utcOffsetMinutes: 480,
  scope: {
    region: "Nordics",
    countries: ["Finland", "Sweden", "Denmark", "Norway", "Iceland"],
    sector: "ophthalmic medical technology",
    include: ["ophthalmic devices", "retinal imaging", "fundus cameras", "OCT", "eye screening hardware", "ophthalmic AI tied to a device"],
    exclude: ["generic medtech", "non-ophthalmic devices", "pure SaaS", "pharma", "biotech", "IVD/testing-only companies"]
  },
  requiredLinkedInLinks: {
    company: true,
    ceoOrFounder: true
  },
  defaultSort: {
    field: "updatedAt",
    direction: "desc"
  },
  filters: [
    { label: "全部", value: "all" },
    { label: "高优先级", value: "高优先级" },
    { label: "本次新增", value: "本次新增" }
  ],
  dataFiles: {
    accounts: "data/accounts.js",
    runs: "data/runs.js"
  }
};
